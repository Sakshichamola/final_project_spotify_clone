export const backendUrl = "http://localhost:8080";
